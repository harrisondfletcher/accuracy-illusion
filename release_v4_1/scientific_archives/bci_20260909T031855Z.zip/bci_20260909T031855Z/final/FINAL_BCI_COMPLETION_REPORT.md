# FINAL BCI COMPLETION REPORT

## A. Execution identity

- Supplied package zip: `Accuracy_Illusion_Revision_v4.zip` sha256 `567c45a3bbb7067dc606c098bc1638be9366eac61f1aabc4c3dab80fa11d35cb` (differs from the handoff-inspected `0e91e64f...` package; difference inventoried in audit/RUNLOG.md, amendment A14).
- Patched source revision: git `dc155bd0b7f3374a281f7f24409137295e105081`; executed script hashes in the final JSON `source_code_sha256` field.
- Design fingerprint: `eabbe1298c88df656e514eb6ea04b112788b5d16bbe3bb29e4994c8ec92642dd`; frozen 2026-09-09T03:37:41.260093+00:00 (before any E-session decoding).
- Environment: Python 3.12.13; moabb 1.7.1, mne 1.12.1, scikit-learn 1.8.0, numpy 2.3.5, scipy 1.17.0, matplotlib 3.10.8; lock at `bci_runs/bci_20260909T031855Z/environment.lock.txt`.
- Final run UTC: 2026-09-09T03:37:57.710569+00:00 to 2026-09-09T03:52:55.939900+00:00; summed subject runtime 897.9 s; command lines in audit/RUNLOG.md and bci_runs/bci_20260909T031855Z/final_execution.log.
- Scope completed: preflight (all 18 files), S1 T-only train-smoke, final evaluate (9 subjects x 2 decoders, 10,000 bootstrap / 5,000 permutations, seed 42), final-mode independent validation, document population, figures, release.

## B. Source data and interpretation

- 18 official BNCI 001-2014 MAT files; 17 reused as `existing_local_file` after decisive full-parse validation, A03E.mat re-downloaded after its local copy failed deep parse (zlib truncation from a disk-full interruption; a valid MAT header and plausible size had masked it). Hashes: `audit/raw_data_sha256.txt`, `bci_runs/bci_20260909T031855Z/source_inventory.json`.
- Every session: 3 zero-trial calibration records (logged separately) + 6 task records of 48 trials, 12 per class; 250 Hz; 25 channels (22 EEG + 3 EOG, EEG order per pinned MOABB source, byte-identical installed vs v1.7.1 tag).
- Labels: source y in 1..4 mapped by explicit canonical ordering (left_hand, right_hand, feet, tongue) after name normalization; alphabetical/reordered class vectors are schema failures (tested).
- Units: microvolts converted to volts once (matches pinned converter).
- Event anchor proof: MAT `trial` is the trial trigger; cue = trigger + 500 samples; epoch = samples [s0+625, s0+1125] inclusive, 501 samples = 0.5-2.5 s post-cue. Impulse-fixture test rejects both missing- and double-offset extraction. Per-trial coordinates in the trial ledger (5,184 rows, sha256 in preflight JSON).
- Artifact policy: organizer per-trial `artifacts` flags applied as an explicit exclusion mask; set equality of flagged and excluded UIDs enforced (gate A1), identical across decoders and bands (A2). NOTE: the previously shipped pipeline's `artifact_handling="ignore"` + `reject_by_annotation=True` combination rejected zero trials; and even "reject" mode with default artifact_interval creates zero-duration annotations at the trigger, outside the 2.5-4.5 s epoch. Both verified against pinned source (audit/RUNLOG.md).
- Duration: all 282 within-run inter-trigger intervals per E session, before exclusion. Audit finding: all 18 files share one fixed pseudorandom trigger schedule; tau-bar = 8.0431 s (SD 0.271, range 7.58-8.48) identically for every subject/session. Recorded as a dataset property with independent raw verification.

## C. Primary results (fixed-window OVR-CSP + shrinkage LDA)

| subject | clean E n | retention | accuracy | kappa | plugin MI | MM correction | corrected MI [CI] | raw p | Holm p | B_min [CI] | ITR ref bpm | V(.60) | V(.70) | V(.80) | cycle s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S1 | 281 | 0.976 | 0.779 | 0.706 | 1.2080 | 0.0128 | 1.1952 [1.1016, 1.3341] | 0.00020 | 0.00180 | 8.916 [8.218, 9.952] | 6.631 | 4 | 3 | 2 | 8.0431 |
| S2 | 283 | 0.983 | 0.445 | 0.261 | 0.2189 | 0.0204 | 0.1985 [0.1443, 0.3051] | 0.00020 | 0.00180 | 1.481 [1.076, 2.276] | 0.965 | 1 | 0 | 0 | 8.0431 |
| S3 | 273 | 0.948 | 0.740 | 0.653 | 0.9506 | 0.0159 | 0.9347 [0.8341, 1.0846] | 0.00020 | 0.00180 | 6.973 [6.222, 8.091] | 5.676 | 3 | 3 | 1 | 8.0431 |
| S4 | 228 | 0.792 | 0.588 | 0.452 | 0.6162 | 0.0253 | 0.5909 [0.4966, 0.7551] | 0.00020 | 0.00180 | 4.408 [3.705, 5.633] | 2.752 | 2 | 0 | 0 | 8.0431 |
| S5 | 276 | 0.958 | 0.399 | 0.200 | 0.1107 | 0.0235 | 0.0872 [0.0503, 0.1782] | 0.00020 | 0.00180 | 0.651 [0.375, 1.329] | 0.572 | 0 | 0 | 0 | 8.0431 |
| S6 | 215 | 0.747 | 0.414 | 0.217 | 0.1255 | 0.0268 | 0.0987 [0.0589, 0.2095] | 0.00020 | 0.00180 | 0.736 [0.439, 1.563] | 0.691 | 0 | 0 | 0 | 8.0431 |
| S7 | 277 | 0.962 | 0.708 | 0.612 | 0.9069 | 0.0130 | 0.8939 [0.7853, 1.0412] | 0.00020 | 0.00180 | 6.668 [5.858, 7.767] | 4.959 | 4 | 2 | 0 | 8.0431 |
| S8 | 271 | 0.941 | 0.775 | 0.700 | 1.0150 | 0.0186 | 0.9964 [0.8769, 1.1754] | 0.00020 | 0.00180 | 7.433 [6.542, 8.768] | 6.519 | 4 | 3 | 1 | 8.0431 |
| S9 | 264 | 0.917 | 0.731 | 0.641 | 1.0211 | 0.0164 | 1.0047 [0.9089, 1.1510] | 0.00020 | 0.00180 | 7.495 [6.780, 8.586] | 5.474 | 3 | 2 | 2 | 8.0431 |

All values derive from `bci_runs/bci_20260909T031855Z/final/bci_real_application_v4.json` (sha256 `5b8075d274a57153421ba078212df9554bc48e8609d42d6684c1c08b6915da38`); field paths per audit/CLAIM_TO_FIELD_MAP.md. The independence test rejected after Holm adjustment for all nine subjects (all raw p = 0.00020 = 1/5001, the permutation floor; exceedances = 0).

## D. Robustness results (FBCSP-style)

| subject | clean E n | retention | accuracy | kappa | plugin MI | MM correction | corrected MI [CI] | raw p | Holm p | B_min [CI] | ITR ref bpm | V(.60) | V(.70) | V(.80) | cycle s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| S1 | 281 | 0.976 | 0.854 | 0.805 | 1.3985 | 0.0077 | 1.3908 [1.2880, 1.5279] | 0.00020 | 0.00180 | 10.375 [9.608, 11.397] | 8.722 | 4 | 4 | 3 | 8.0431 |
| S2 | 283 | 0.983 | 0.403 | 0.208 | 0.1895 | 0.0178 | 0.1717 [0.1311, 0.2596] | 0.00020 | 0.00180 | 1.281 [0.978, 1.936] | 0.604 | 0 | 0 | 0 | 8.0431 |
| S3 | 273 | 0.948 | 0.813 | 0.751 | 1.1923 | 0.0185 | 1.1738 [1.0582, 1.3483] | 0.00020 | 0.00180 | 8.756 [7.894, 10.058] | 7.528 | 4 | 3 | 2 | 8.0431 |
| S4 | 228 | 0.792 | 0.680 | 0.573 | 0.8113 | 0.0285 | 0.7829 [0.6716, 0.9756] | 0.00020 | 0.00180 | 5.840 [5.010, 7.278] | 4.386 | 3 | 2 | 0 | 8.0431 |
| S5 | 276 | 0.958 | 0.609 | 0.480 | 0.5727 | 0.0183 | 0.5544 [0.4555, 0.7010] | 0.00020 | 0.00180 | 4.136 [3.398, 5.230] | 3.090 | 2 | 2 | 0 | 8.0431 |
| S6 | 215 | 0.747 | 0.498 | 0.331 | 0.2809 | 0.0235 | 0.2574 [0.1888, 0.3819] | 0.00020 | 0.00180 | 1.920 [1.408, 2.849] | 1.521 | 0 | 0 | 0 | 8.0431 |
| S7 | 277 | 0.962 | 0.866 | 0.822 | 1.3840 | 0.0078 | 1.3762 [1.2608, 1.5209] | 0.00020 | 0.00180 | 10.266 [9.405, 11.346] | 9.109 | 4 | 4 | 4 | 8.0431 |
| S8 | 271 | 0.941 | 0.812 | 0.749 | 1.0829 | 0.0186 | 1.0642 [0.9396, 1.2453] | 0.00020 | 0.00180 | 7.939 [7.009, 9.289] | 7.490 | 4 | 4 | 2 | 8.0431 |
| S9 | 264 | 0.917 | 0.697 | 0.595 | 0.8271 | 0.0191 | 0.8080 [0.7026, 0.9684] | 0.00020 | 0.00180 | 6.028 [5.241, 7.224] | 4.735 | 3 | 3 | 1 | 8.0431 |

Paired contrasts (identical bootstrap resamples): FBCSP improves accuracy for 7/9 subjects; decreases for S2 (-0.042) and S9 (-0.034). Full paired deltas with 95% intervals in the completed Supplementary Table S8. All-scheduled sensitivity (frozen decoders, flagged epochs included): corrected MI within 0.05 bits of the clean estimate for every subject and decoder; no conclusion changes.

## E. Threshold curves and confusion structure

- Primary: mean V_eff at alpha .40/.50/.60/.70/.80/.90 = 3.44/2.67/2.33/1.44/0.67/0.00; subjects with at least one qualifying intent: 9/8/7/5/4/0.
- Confusion structure is heterogeneous and class-specific (feet-tongue confusion in S1/S3/S4/S7 with S8 reversed; hand asymmetries in S1/S4/S9; S5 diffuse vs S6 right-hand-column collapse). No common failure mechanism is asserted. Cell-level descriptions with values are in manuscript Section 6.3.

## F. Validation and tests

- Final validator: PASS, 713 recomputation checks, 0 failures. Per gate: A1 54/54, A2 9/9, C1 27/27, D1 4/4, D2 36/36, I1 36/36, I2 306/306, I3 20/20, I4 72/72, L1 36/36, L2 9/9, R1 4/4, R2 72/72, R3 1/1, T1 9/9, T2 18/18. Report: `bci_runs/bci_20260909T031855Z/final_validation.json`.
- Preflight validation: PASS (142 checks). Smoke validation: PASS (65 checks, result_kind=smoke, manuscript-ineligible).
- Test suite: 39 passed (8 simulation regression + 31 new including the 11-scenario tamper battery); logs `tests_before.log` / `tests_after.log`. Gate R4 (simulation artifacts unchanged from baseline): PASS by git diff against the baseline commit.
- No gate anywhere conditions on performance level (verified by test: a chance-level decoder passes).

## G. Scientific interpretation and limitations

- Clean-subset estimates are conditional on organizer-retained trials (E retention .747-.983); the prespecified all-scheduled sensitivity shows the conditioning is immaterial here.
- Bootstrap intervals are conditional descriptive intervals for the fitted models, observed strata, and fixed measured cycle; they exclude training/model-selection uncertainty and future-session variability.
- Zero-phase FIR filtering is offline; results are offline fixed-window information normalized by the recorded within-run cycle, not a causal deployed throughput.
- Ang et al. (2012) kappas (.503 CSP, .569 FBCSP) are context under different (causal, time-resolved, max-kappa) evaluation; observed means (.494 primary, .590 FBCSP) sit near them but are not comparable point-for-point.
- Permutation nulls assume within-run exchangeability of labels given frozen predictions; Holm is applied within each nine-test decoder family, families kept separate.
- C_k, R, and behavioral U are unmeasured by design on this dataset; artifact rejection is not abstention.
- E labels are public; this is a revision-stage analysis of a public benchmark under a documented pre-evaluation freeze, not a prospectively registered unseen study.

## H. Documents and release

- Completed manuscript: `docs release/The_Accuracy_Illusion_v4_BCI_completed.md` + `.docx`; completed Supplement S8: same directory. Response letter and revision audit carry dated executed-completion addenda.
- Figures: fig2_bci_subjects, fig4_confusion, figS8_fbcsp_confusion (png+pdf), generated from the validated JSON; interval endpoints drawn without clamping.
- Claim-to-field map: audit/CLAIM_TO_FIELD_MAP.md. Residual placeholder scan: none.
- Simulation artifacts: unchanged (git-verified); full simulation re-run not performed in this task (out of scope per handoff SS17; hash check only, stated as such).
- Release manifest generated last, excluding itself, archives, venv, raw EEG, caches; archive + external sha256 sidecar paths recorded below on creation.

## I. Deviations and open items

1. Package identity differs from the handoff-inspected zip (A14): file tree and interfaces match the handoff's audit; per-file inventory at the baseline commit. Unresolvable to file granularity without the original package.
2. A03E.mat local copy was corrupt and re-downloaded (Section B). 
3. All 18 files share one trigger schedule; tau variance across subjects is zero. Dataset property, independently verified; B_min differences across subjects are therefore driven purely by MI.
4. All raw permutation p-values sit at the 1/5001 floor for both decoders (even the weakest subject carries strong evidence against independence at N>=215); Holm-adjusted values are reported and no stronger claim is made.
5. DOCX rendering used pandoc with the repository's existing reference styling; visual inspection performed on the rendered HTML/PDF proofs. Journal-format (APA) compliance was NOT separately verified and is not claimed.
6. The full simulation reproduction (SS17 second claim) remains a separate stage; only hash verification was performed here.
7. MOABB is retained in requirements for audit parity but the production data path is the local adapter; the smoke phase never opens E files.
