"""Validate every runtime gate required before Section 6 is populated."""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path

REQUIRED_DECODER_FIELDS = (
    "N", "accuracy", "kappa", "mi_plugin_bits", "mi_mm_correction_bits",
    "mi_corrected_bits", "mi_ci_bits", "mi_perm_p_raw", "mi_perm_p_holm",
    "b_min_bpm", "b_min_ci_bpm", "itr_bpm", "f1_per_class",
    "veff_curve", "confusion_matrix",
)


def validate(path: str | Path, require_all_subjects: bool = True) -> dict:
    path = Path(path)
    data = json.loads(path.read_text(encoding="utf-8"))
    errors: list[str] = []
    if data.get("status") != "complete":
        errors.append(f"status is {data.get('status')!r}, not 'complete'")
    expected = [f"S{i}" for i in range(1, 10)]
    subjects = data.get("subjects", {})
    if require_all_subjects and sorted(subjects) != expected:
        errors.append(f"subject keys are {sorted(subjects)}, expected {expected}")

    for subject, record in subjects.items():
        if record.get("n_eeg_channels") != 22:
            errors.append(f"{subject}: n_eeg_channels != 22")
        evaluation = record.get("run_structure", {}).get("evaluation", {})
        if evaluation.get("source_runs_inferred") != 6:
            errors.append(f"{subject}: source_runs_inferred != 6")
        if evaluation.get("n_within_run_intervals") != 282:
            errors.append(f"{subject}: n_within_run_intervals != 282")
        if not math.isfinite(float(evaluation.get("tau_mean_sec", float("nan")))):
            errors.append(f"{subject}: invalid tau_mean_sec")

        artifacts = record.get("artifact_accounting", {})
        for session in ("training", "evaluation"):
            item = artifacts.get(session, {})
            if item.get("n_all") != 288:
                errors.append(f"{subject}/{session}: n_all != 288")
            if item.get("n_clean", -1) + item.get("n_dropped", -1) != 288:
                errors.append(f"{subject}/{session}: clean + dropped != 288")
            if sum(item.get("dropped_by_class", {}).values()) != item.get("n_dropped"):
                errors.append(f"{subject}/{session}: class exclusion counts do not sum")

        decoder_map = record.get("decoders", {})
        if set(decoder_map) != {"primary", "fbcsp"}:
            errors.append(f"{subject}: decoder keys are {sorted(decoder_map)}")
        for decoder, result in decoder_map.items():
            for field in REQUIRED_DECODER_FIELDS:
                if field not in result:
                    errors.append(f"{subject}/{decoder}: missing {field}")
            if "confusion_matrix" not in result:
                continue
            cm = result["confusion_matrix"]
            if len(cm) != 4 or any(len(row) != 4 for row in cm):
                errors.append(f"{subject}/{decoder}: confusion matrix is not 4x4")
            elif sum(sum(row) for row in cm) != result.get("N"):
                errors.append(f"{subject}/{decoder}: confusion-matrix N mismatch")
            for p_field in ("mi_perm_p_raw", "mi_perm_p_holm"):
                p_value = result.get(p_field)
                if p_value is None or not 0 <= p_value <= 1:
                    errors.append(f"{subject}/{decoder}: invalid {p_field}")
            if len(result.get("f1_per_class", [])) != 4:
                errors.append(f"{subject}/{decoder}: expected four F1 values")
            if set(result.get("veff_curve", {})) != {
                "0.4", "0.5", "0.6", "0.7", "0.8", "0.9"
            }:
                errors.append(f"{subject}/{decoder}: incomplete V_eff curve")

    if errors:
        raise SystemExit("BCI validation failed:\n- " + "\n- ".join(errors))
    print(f"BCI validation passed: {path}")
    return data


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("path", nargs="?", default="results/bci_real_application_v4.json")
    args = parser.parse_args()
    validate(args.path)
