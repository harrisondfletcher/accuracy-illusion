"""Supplementary Code S1b: rigorous BCI Competition IV-2a re-analysis.

This program is deliberately separate from simulation reproduction because it
requires the public IV-2a data. It supports MOABB releases that expose either
one concatenated Raw object per session or one Raw object per source run.

Primary decoder
---------------
* Subject-specific training-session T -> evaluation-session E.
* Organizer-annotated artifacts rejected by MNE Epochs.
* Exactly 22 EEG channels; EOG never enters classifier features.
* Fixed 0.5--2.5 s post-cue window; 8--30 Hz zero-phase MNE FIR filter.
* One-vs-rest CSP + shrinkage LDA; 4/6/8 CSP components selected by
  five-fold cross-validation on T only; E evaluated once.

Robustness decoder
------------------
* Nine 4-Hz bands from 4--40 Hz.
* Binary one-vs-rest CSP for each band/class, fitted inside each training fold.
* Number of retained features selected on T only; shrinkage LDA; E once.
* Described as FBCSP-style, not an exact reproduction of Ang et al. (2012).

Inference and reporting
-----------------------
* Full-cycle duration from all 282 within-source-run inter-cue intervals.
* Plug-in and observed-support Miller--Madow MI; no truncation at zero.
* Class-stratified 10,000-resample intervals.
* 5,000-label permutation p-values with (b+1)/(B+1), Holm-adjusted across
  subjects separately for each decoder.
* Accuracy, kappa, conventional Wolpaw ITR, class precision/recall/F1,
  V_eff threshold curves, artifact accounting, confusion matrices, predictions,
  software versions, filter specifications, and runtime gates.
"""
from __future__ import annotations

import argparse
import csv
import importlib.metadata as metadata
import json
import math
import os
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import mne
import numpy as np
from mne.decoding import CSP
from moabb.datasets import BNCI2014_001
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.feature_selection import SelectKBest, mutual_info_classif
from sklearn.metrics import cohen_kappa_score, confusion_matrix, make_scorer
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.multiclass import OneVsRestClassifier
from sklearn.pipeline import Pipeline

SEED = 42
CLASSES = ("left_hand", "right_hand", "feet", "tongue")
EVENT_ID = {name: i + 1 for i, name in enumerate(CLASSES)}
K = len(CLASSES)
LN2 = math.log(2.0)
FILTERBANK_BANDS = tuple((float(lo), float(lo + 4)) for lo in range(4, 40, 4))
CUE_DESCRIPTORS = set(CLASSES) | {"769", "770", "771", "772"}


@dataclass(frozen=True)
class BCIConfig:
    epoch_tmin_postcue: float = 0.5
    epoch_tmax_postcue: float = 2.5
    primary_fmin: float = 8.0
    primary_fmax: float = 30.0
    primary_component_grid: tuple[int, ...] = (4, 6, 8)
    fbcsp_components_per_class_band: int = 4
    fbcsp_feature_grid: tuple[int, ...] = (16, 32, 64, 96)
    cv_folds: int = 5
    csp_regularization: str = "ledoit_wolf"
    veff_beta: int = 30
    n_bootstrap: int = 10_000
    n_permutations: int = 5_000
    random_seed: int = SEED


def software_versions() -> dict[str, str | None]:
    names = ("moabb", "mne", "scikit-learn", "numpy", "scipy", "matplotlib")
    out: dict[str, str | None] = {}
    for name in names:
        try:
            out[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            out[name] = None
    return out


def dataset_instance():
    """Instantiate BNCI2014_001 across MOABB API variants.

    Artifact rejection is never delegated to this constructor; it is performed
    explicitly by MNE Epochs from organizer-provided ``bad_*`` annotations.
    """
    try:
        return BNCI2014_001(artifact_handling="ignore")
    except TypeError:
        return BNCI2014_001()


def resolve_sessions(names: Iterable[object]) -> tuple[str, str]:
    labels = [str(x) for x in names]
    train = [x for x in labels if "train" in x.lower()]
    test = [x for x in labels if "test" in x.lower() or "eval" in x.lower()]
    if len(train) != 1 or len(test) != 1:
        raise RuntimeError(
            "Could not uniquely resolve training/evaluation sessions by name: "
            f"{labels}"
        )
    return train[0], test[0]


def subject_tree(dataset, subject: int):
    tree = dataset.get_data(subjects=[subject])
    if subject not in tree:
        raise RuntimeError(f"Dataset did not return subject {subject}")
    sessions = tree[subject]
    train_name, test_name = resolve_sessions(sessions.keys())
    train_runs, test_runs = sessions[train_name], sessions[test_name]
    if not isinstance(train_runs, dict) or not isinstance(test_runs, dict):
        raise TypeError("Expected MOABB session values to be run dictionaries")
    if not train_runs or not test_runs:
        raise RuntimeError(f"S{subject}: empty run dictionary")
    return train_name, test_name, train_runs, test_runs


def normalized_annotation_name(value: object) -> str:
    return str(value).strip().lower().split("/")[-1]


def cue_events(raw: mne.io.BaseRaw) -> np.ndarray:
    events, mapping = mne.events_from_annotations(raw, verbose=False)
    cue_codes = [
        code
        for description, code in mapping.items()
        if normalized_annotation_name(description) in CUE_DESCRIPTORS
    ]
    if not cue_codes:
        raise RuntimeError(f"Could not resolve cue annotations from {mapping}")
    return events[np.isin(events[:, 2], cue_codes)]


def source_run_structure(run_dict: dict) -> dict:
    """Verify six source runs whether MOABB preserves or concatenates them."""
    if len(run_dict) == 6:
        cue_counts = {}
        within: list[float] = []
        for run_id, raw in sorted(run_dict.items(), key=lambda item: str(item[0])):
            events = cue_events(raw)
            if len(events) != 48:
                raise RuntimeError(
                    f"Run {run_id}: expected 48 cue events, found {len(events)}"
                )
            times = events[:, 0] / float(raw.info["sfreq"])
            cue_counts[str(run_id)] = int(len(times))
            within.extend(np.diff(times).tolist())
        if len(within) != 282:
            raise RuntimeError(f"Expected 282 within-run intervals, found {len(within)}")
        return {
            "moabb_run_objects": 6,
            "source_runs_inferred": 6,
            "cue_count_by_run": cue_counts,
            "within_run_intervals_sec": np.asarray(within, float),
            "between_run_gaps_sec": np.asarray([], float),
            "representation": "six source runs preserved",
        }

    if len(run_dict) == 1:
        run_id, raw = next(iter(run_dict.items()))
        events = cue_events(raw)
        if len(events) != 288:
            raise RuntimeError(
                f"Concatenated session {run_id}: expected 288 cues, found {len(events)}"
            )
        times = events[:, 0] / float(raw.info["sfreq"])
        differences = np.diff(times)
        within = differences[differences < 10.0]
        between = differences[differences >= 10.0]
        if len(within) != 282 or len(between) != 5:
            raise RuntimeError(
                "Could not recover six source runs from concatenated session: "
                f"{len(within)} within-run intervals and {len(between)} gaps"
            )
        return {
            "moabb_run_objects": 1,
            "source_runs_inferred": 6,
            "cue_count_by_run": {str(run_id): 288},
            "within_run_intervals_sec": within,
            "between_run_gaps_sec": between,
            "representation": "six source runs concatenated by MOABB",
        }

    raise RuntimeError(
        "Unsupported MOABB run representation: expected one concatenated object "
        f"or six source-run objects, found {len(run_dict)}"
    )


def cycle_summary(test_runs: dict) -> dict:
    structure = source_run_structure(test_runs)
    within = structure.pop("within_run_intervals_sec")
    between = structure.pop("between_run_gaps_sec")
    return {
        **structure,
        "n_within_run_intervals": int(len(within)),
        "tau_mean_sec": float(np.mean(within)),
        "tau_sd_sec": float(np.std(within, ddof=1)),
        "tau_min_sec": float(np.min(within)),
        "tau_max_sec": float(np.max(within)),
        "n_between_run_gaps": int(len(between)),
        "between_run_gaps_sec": between.tolist(),
    }


def filter_specification(raw: mne.io.BaseRaw, l_freq: float, h_freq: float) -> dict:
    n_times = min(int(raw.n_times), 20_000)
    kernel = mne.filter.create_filter(
        np.zeros((1, n_times), dtype=float),
        sfreq=float(raw.info["sfreq"]),
        l_freq=l_freq,
        h_freq=h_freq,
        method="fir",
        phase="zero",
        fir_design="firwin",
        filter_length="auto",
        l_trans_bandwidth="auto",
        h_trans_bandwidth="auto",
        verbose=False,
    )
    return {
        "l_freq_hz": l_freq,
        "h_freq_hz": h_freq,
        "method": "fir",
        "phase": "zero",
        "fir_design": "firwin",
        "filter_length": "auto",
        "l_trans_bandwidth": "auto",
        "h_trans_bandwidth": "auto",
        "resolved_n_taps": int(kernel.shape[-1]),
        "sampling_rate_hz": float(raw.info["sfreq"]),
    }


def filter_eeg(raw: mne.io.BaseRaw, l_freq: float, h_freq: float):
    eeg = raw.copy().pick(picks="eeg")
    if len(eeg.ch_names) != 22:
        raise RuntimeError(
            f"Expected exactly 22 EEG channels after EOG exclusion, found "
            f"{len(eeg.ch_names)}: {eeg.ch_names}"
        )
    eeg.filter(
        l_freq=l_freq,
        h_freq=h_freq,
        method="fir",
        phase="zero",
        fir_design="firwin",
        filter_length="auto",
        l_trans_bandwidth="auto",
        h_trans_bandwidth="auto",
        picks="eeg",
        verbose=False,
    )
    return eeg


def epoch_one_run(
    raw: mne.io.BaseRaw,
    run_id: str,
    l_freq: float,
    h_freq: float,
    cfg: BCIConfig,
):
    eeg = filter_eeg(raw, l_freq, h_freq)
    events = cue_events(eeg)
    kwargs = dict(
        event_id=EVENT_ID,
        tmin=cfg.epoch_tmin_postcue,
        tmax=cfg.epoch_tmax_postcue,
        baseline=None,
        detrend=None,
        proj=False,
        preload=True,
        verbose=False,
    )
    all_epochs = mne.Epochs(eeg, events, reject_by_annotation=False, **kwargs)
    clean_epochs = mne.Epochs(eeg, events, reject_by_annotation=True, **kwargs)
    y_all = all_epochs.events[:, -1].astype(int) - 1
    y_clean = clean_epochs.events[:, -1].astype(int) - 1
    all_counts = np.bincount(y_all, minlength=K)
    clean_counts = np.bincount(y_clean, minlength=K)
    dropped = all_counts - clean_counts
    if np.any(dropped < 0):
        raise RuntimeError("Artifact accounting produced a negative count")
    identifiers = [
        (str(run_id), int(sample), int(label))
        for sample, label in zip(clean_epochs.events[:, 0], y_clean)
    ]
    return {
        "X": clean_epochs.get_data(copy=True).astype(np.float32),
        "y": y_clean,
        "identifiers": identifiers,
        "n_all": int(len(all_epochs)),
        "n_clean": int(len(clean_epochs)),
        "n_dropped": int(len(all_epochs) - len(clean_epochs)),
        "all_by_class": {name: int(all_counts[i]) for i, name in enumerate(CLASSES)},
        "clean_by_class": {name: int(clean_counts[i]) for i, name in enumerate(CLASSES)},
        "dropped_by_class": {name: int(dropped[i]) for i, name in enumerate(CLASSES)},
        "channel_names": eeg.ch_names,
        "filter": filter_specification(raw, l_freq, h_freq),
    }


def epoch_session(
    run_dict: dict,
    l_freq: float,
    h_freq: float,
    cfg: BCIConfig,
):
    chunks = [
        epoch_one_run(raw, str(run_id), l_freq, h_freq, cfg)
        for run_id, raw in sorted(run_dict.items(), key=lambda item: str(item[0]))
    ]
    X = np.concatenate([chunk["X"] for chunk in chunks], axis=0)
    y = np.concatenate([chunk["y"] for chunk in chunks], axis=0)
    identifiers = [item for chunk in chunks for item in chunk["identifiers"]]
    all_by = {name: sum(chunk["all_by_class"][name] for chunk in chunks) for name in CLASSES}
    clean_by = {name: sum(chunk["clean_by_class"][name] for chunk in chunks) for name in CLASSES}
    dropped_by = {name: all_by[name] - clean_by[name] for name in CLASSES}
    n_all = sum(chunk["n_all"] for chunk in chunks)
    n_clean = sum(chunk["n_clean"] for chunk in chunks)
    if n_all != 288:
        raise RuntimeError(f"Expected 288 source trials in session, found {n_all}")
    if any(chunk["channel_names"] != chunks[0]["channel_names"] for chunk in chunks):
        raise RuntimeError("EEG channel ordering differs across runs")
    return {
        "X": X,
        "y": y,
        "identifiers": identifiers,
        "n_all": int(n_all),
        "n_clean": int(n_clean),
        "n_dropped": int(n_all - n_clean),
        "all_by_class": all_by,
        "clean_by_class": clean_by,
        "dropped_by_class": dropped_by,
        "retention": float(n_clean / n_all),
        "channel_names": chunks[0]["channel_names"],
        "filter": chunks[0]["filter"],
    }


def primary_estimator(n_components: int):
    return OneVsRestClassifier(
        Pipeline(
            [
                (
                    "csp",
                    CSP(
                        n_components=n_components,
                        reg="ledoit_wolf",
                        log=True,
                        norm_trace=False,
                        cov_est="concat",
                    ),
                ),
                (
                    "lda",
                    LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto"),
                ),
            ]
        ),
        n_jobs=1,
    )


def fit_primary(X_train, y_train, X_test, cfg: BCIConfig):
    cv = StratifiedKFold(
        n_splits=cfg.cv_folds,
        shuffle=True,
        random_state=cfg.random_seed,
    )
    search = GridSearchCV(
        primary_estimator(6),
        {"estimator__csp__n_components": list(cfg.primary_component_grid)},
        scoring=make_scorer(cohen_kappa_score),
        cv=cv,
        refit=True,
        n_jobs=1,
        return_train_score=False,
    )
    search.fit(X_train, y_train)
    return search.predict(X_test), {
        "selected_components_per_binary_problem": int(
            search.best_params_["estimator__csp__n_components"]
        ),
        "training_cv_mean_kappa": float(search.best_score_),
        "candidate_components": list(cfg.primary_component_grid),
    }


class OVRFilterBankCSP(BaseEstimator, TransformerMixin):
    """Binary one-vs-rest CSP for every filter band and target class."""

    def __init__(self, n_components: int = 4, reg: str = "ledoit_wolf"):
        self.n_components = n_components
        self.reg = reg

    def fit(self, X, y):
        X = np.asarray(X)
        y = np.asarray(y)
        if X.ndim != 4:
            raise ValueError("Expected X with shape epochs x bands x channels x time")
        self.classes_ = np.unique(y)
        self.models_ = []
        for band in range(X.shape[1]):
            row = []
            for target in self.classes_:
                model = CSP(
                    n_components=self.n_components,
                    reg=self.reg,
                    log=True,
                    norm_trace=False,
                    cov_est="concat",
                )
                model.fit(X[:, band], (y == target).astype(int))
                row.append(model)
            self.models_.append(row)
        return self

    def transform(self, X):
        X = np.asarray(X)
        return np.concatenate(
            [
                model.transform(X[:, band])
                for band, row in enumerate(self.models_)
                for model in row
            ],
            axis=1,
        )


def deterministic_mutual_information(X, y):
    return mutual_info_classif(X, y, random_state=SEED)


def fit_fbcsp(X_train, y_train, X_test, cfg: BCIConfig):
    total_features = len(FILTERBANK_BANDS) * K * cfg.fbcsp_components_per_class_band
    candidate_k = [k for k in cfg.fbcsp_feature_grid if k <= total_features]
    if not candidate_k:
        raise ValueError("No admissible FBCSP feature-count candidate")
    estimator = Pipeline(
        [
            (
                "fbcsp",
                OVRFilterBankCSP(
                    n_components=cfg.fbcsp_components_per_class_band,
                    reg=cfg.csp_regularization,
                ),
            ),
            ("select", SelectKBest(deterministic_mutual_information, k=candidate_k[0])),
            ("lda", LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")),
        ]
    )
    cv = StratifiedKFold(
        n_splits=cfg.cv_folds,
        shuffle=True,
        random_state=cfg.random_seed,
    )
    search = GridSearchCV(
        estimator,
        {"select__k": candidate_k},
        scoring=make_scorer(cohen_kappa_score),
        cv=cv,
        refit=True,
        n_jobs=1,
        return_train_score=False,
    )
    search.fit(X_train, y_train)
    return search.predict(X_test), {
        "bands_hz": [list(x) for x in FILTERBANK_BANDS],
        "csp_components_per_class_band": cfg.fbcsp_components_per_class_band,
        "total_preselection_features": total_features,
        "selected_features": int(search.best_params_["select__k"]),
        "candidate_feature_counts": candidate_k,
        "training_cv_mean_kappa": float(search.best_score_),
    }


def mi_components(cm: np.ndarray) -> dict:
    cm = np.asarray(cm, dtype=float)
    n = float(cm.sum())
    if n <= 0:
        raise ValueError("Empty confusion matrix")
    joint = cm / n
    py = joint.sum(axis=1, keepdims=True)
    pz = joint.sum(axis=0, keepdims=True)
    with np.errstate(divide="ignore", invalid="ignore"):
        plugin = float(
            np.where(joint > 0, joint * np.log2(joint / (py * pz)), 0.0).sum()
        )
    k_yz = int((joint > 0).sum())
    k_y = int((py > 0).sum())
    k_z = int((pz > 0).sum())
    correction = (k_yz - k_y - k_z + 1) / (2.0 * n * LN2)
    return {
        "mi_plugin_bits": plugin,
        "mi_mm_correction_bits": float(correction),
        "mi_corrected_bits": float(plugin - correction),
        "K_y": k_y,
        "K_z": k_z,
        "K_yz": k_yz,
        "N": int(n),
    }


def precision_recall_f1(cm: np.ndarray):
    cm = np.asarray(cm, dtype=float)
    tp = np.diag(cm)
    fp = cm.sum(axis=0) - tp
    fn = cm.sum(axis=1) - tp
    with np.errstate(divide="ignore", invalid="ignore"):
        precision = np.where(tp + fp > 0, tp / (tp + fp), 0.0)
        recall = np.where(tp + fn > 0, tp / (tp + fn), 0.0)
        f1 = np.where(
            precision + recall > 0,
            2 * precision * recall / (precision + recall),
            0.0,
        )
    return precision, recall, f1


def veff_curve(cm: np.ndarray, beta: int) -> dict[str, int]:
    _, _, f1 = precision_recall_f1(cm)
    support = np.asarray(cm).sum(axis=1)
    return {
        str(alpha): int(np.sum((f1 >= alpha) & (support >= beta)))
        for alpha in (0.40, 0.50, 0.60, 0.70, 0.80, 0.90)
    }


def itr_bits_per_trial(accuracy: float, n_classes: int = K) -> float:
    if accuracy <= 1 / n_classes:
        return 0.0
    if accuracy >= 1:
        return math.log2(n_classes)
    return (
        math.log2(n_classes)
        + accuracy * math.log2(accuracy)
        + (1 - accuracy) * math.log2((1 - accuracy) / (n_classes - 1))
    )


def stratified_bootstrap_indices(y: np.ndarray, rng: np.random.Generator):
    return np.concatenate(
        [
            rng.choice(indices, size=len(indices), replace=True)
            for cls in np.unique(y)
            for indices in [np.flatnonzero(y == cls)]
        ]
    )


def evaluate_decoder(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    tau_mean_sec: float,
    cfg: BCIConfig,
    *,
    seed: int,
):
    rng = np.random.default_rng(seed)
    labels = np.arange(K)
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    observed = mi_components(cm)
    n_boot = cfg.n_bootstrap
    boot = np.empty((n_boot, 3), dtype=float)
    for b in range(n_boot):
        index = stratified_bootstrap_indices(y_true, rng)
        cm_b = confusion_matrix(y_true[index], y_pred[index], labels=labels)
        boot[b, 0] = mi_components(cm_b)["mi_corrected_bits"]
        boot[b, 1] = float(np.mean(y_true[index] == y_pred[index]))
        boot[b, 2] = float(cohen_kappa_score(y_true[index], y_pred[index]))

    observed_corrected = observed["mi_corrected_bits"]
    exceed = 0
    for _ in range(cfg.n_permutations):
        permuted = rng.permutation(y_pred)
        cm_p = confusion_matrix(y_true, permuted, labels=labels)
        exceed += mi_components(cm_p)["mi_corrected_bits"] >= observed_corrected - 1e-15
    p_value = (exceed + 1) / (cfg.n_permutations + 1)

    accuracy = float(np.mean(y_true == y_pred))
    kappa = float(cohen_kappa_score(y_true, y_pred))
    precision, recall, f1 = precision_recall_f1(cm)
    tau_min = tau_mean_sec / 60.0
    mi_lo, mi_hi = np.quantile(boot[:, 0], [0.025, 0.975])
    return {
        **observed,
        "accuracy": accuracy,
        "accuracy_ci": np.quantile(boot[:, 1], [0.025, 0.975]).tolist(),
        "kappa": kappa,
        "kappa_ci": np.quantile(boot[:, 2], [0.025, 0.975]).tolist(),
        "mi_ci_bits": [float(mi_lo), float(mi_hi)],
        "mi_perm_p_raw": float(p_value),
        "tau_mean_sec": float(tau_mean_sec),
        "b_min_bpm": float(observed_corrected / tau_min),
        "b_min_ci_bpm": [float(mi_lo / tau_min), float(mi_hi / tau_min)],
        "itr_bpm": float(itr_bits_per_trial(accuracy) / tau_min),
        "precision_per_class": precision.tolist(),
        "recall_per_class": recall.tolist(),
        "f1_per_class": f1.tolist(),
        "veff_curve": veff_curve(cm, cfg.veff_beta),
        "confusion_matrix": cm.tolist(),
    }


def holm_adjust(p_values: list[float]) -> np.ndarray:
    p = np.asarray(p_values, dtype=float)
    order = np.argsort(p)
    adjusted_ordered = np.maximum.accumulate(
        (len(p) - np.arange(len(p))) * p[order]
    )
    adjusted_ordered = np.minimum(adjusted_ordered, 1.0)
    adjusted = np.empty_like(p)
    adjusted[order] = adjusted_ordered
    return adjusted


def write_predictions(
    output_dir: Path,
    subject: int,
    decoder: str,
    identifiers: list[tuple[str, int, int]],
    y_true: np.ndarray,
    y_pred: np.ndarray,
):
    path = output_dir / f"S{subject}_{decoder}_predictions.csv"
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "subject",
                "decoder",
                "moabb_run_id",
                "event_sample",
                "true_class",
                "predicted_class",
            ]
        )
        for (run_id, sample, identifier_label), truth, predicted in zip(
            identifiers, y_true, y_pred
        ):
            if identifier_label != int(truth):
                raise RuntimeError("Prediction identifier does not match truth label")
            writer.writerow(
                [
                    subject,
                    decoder,
                    run_id,
                    sample,
                    CLASSES[int(truth)],
                    CLASSES[int(predicted)],
                ]
            )
    return str(path)


def prepare_filterbank(
    train_runs: dict,
    test_runs: dict,
    cfg: BCIConfig,
    reference_train: list[tuple[str, int, int]],
    reference_test: list[tuple[str, int, int]],
):
    train_bands = []
    test_bands = []
    filter_specs = []
    for l_freq, h_freq in FILTERBANK_BANDS:
        train = epoch_session(train_runs, l_freq, h_freq, cfg)
        test = epoch_session(test_runs, l_freq, h_freq, cfg)
        if train["identifiers"] != reference_train or test["identifiers"] != reference_test:
            raise RuntimeError(
                f"Epoch ordering differs in filter band {l_freq:g}-{h_freq:g} Hz"
            )
        train_bands.append(train["X"])
        test_bands.append(test["X"])
        filter_specs.append(train["filter"])
    return (
        np.stack(train_bands, axis=1),
        np.stack(test_bands, axis=1),
        filter_specs,
    )


def run_subject(
    dataset,
    subject: int,
    decoders: tuple[str, ...],
    cfg: BCIConfig,
    output_dir: Path,
):
    train_name, test_name, train_runs, test_runs = subject_tree(dataset, subject)
    train_structure = source_run_structure(train_runs)
    test_cycle = cycle_summary(test_runs)
    if train_structure["source_runs_inferred"] != 6:
        raise RuntimeError(f"S{subject}: training source-run gate failed")

    train = epoch_session(
        train_runs, cfg.primary_fmin, cfg.primary_fmax, cfg
    )
    test = epoch_session(test_runs, cfg.primary_fmin, cfg.primary_fmax, cfg)
    if train["channel_names"] != test["channel_names"]:
        raise RuntimeError(f"S{subject}: train/test EEG channel ordering differs")

    result = {
        "subject": f"S{subject}",
        "sessions": {
            "training": train_name,
            "evaluation": test_name,
        },
        "run_structure": {
            "training": {
                key: value
                for key, value in train_structure.items()
                if not key.endswith("intervals_sec") and not key.endswith("gaps_sec")
            },
            "evaluation": test_cycle,
        },
        "n_eeg_channels": len(train["channel_names"]),
        "eeg_channel_names": train["channel_names"],
        "artifact_accounting": {
            "training": {
                key: train[key]
                for key in (
                    "n_all",
                    "n_clean",
                    "n_dropped",
                    "all_by_class",
                    "clean_by_class",
                    "dropped_by_class",
                    "retention",
                )
            },
            "evaluation": {
                key: test[key]
                for key in (
                    "n_all",
                    "n_clean",
                    "n_dropped",
                    "all_by_class",
                    "clean_by_class",
                    "dropped_by_class",
                    "retention",
                )
            },
        },
        "primary_filter": train["filter"],
        "decoders": {},
    }

    if "primary" in decoders:
        prediction, tuning = fit_primary(train["X"], train["y"], test["X"], cfg)
        metrics = evaluate_decoder(
            test["y"],
            prediction,
            test_cycle["tau_mean_sec"],
            cfg,
            seed=cfg.random_seed + 100 * subject,
        )
        result["decoders"]["primary"] = {
            "name": "fixed-window OVR-CSP + shrinkage LDA",
            "training_only_tuning": tuning,
            **metrics,
            "prediction_file": write_predictions(
                output_dir,
                subject,
                "primary",
                test["identifiers"],
                test["y"],
                prediction,
            ),
        }

    if "fbcsp" in decoders:
        X_train_fb, X_test_fb, filter_specs = prepare_filterbank(
            train_runs,
            test_runs,
            cfg,
            train["identifiers"],
            test["identifiers"],
        )
        prediction, tuning = fit_fbcsp(
            X_train_fb, train["y"], X_test_fb, cfg
        )
        metrics = evaluate_decoder(
            test["y"],
            prediction,
            test_cycle["tau_mean_sec"],
            cfg,
            seed=cfg.random_seed + 100 * subject + 1,
        )
        result["decoders"]["fbcsp"] = {
            "name": "nine-band FBCSP-style robustness decoder",
            "scope_note": "not an exact reproduction of Ang et al. (2012)",
            "filter_specs": filter_specs,
            "training_only_tuning": tuning,
            **metrics,
            "prediction_file": write_predictions(
                output_dir,
                subject,
                "fbcsp",
                test["identifiers"],
                test["y"],
                prediction,
            ),
        }
    return result


def parse_subjects(value: str) -> list[int]:
    if value == "1-9":
        return list(range(1, 10))
    subjects = [int(item) for item in value.split(",") if item.strip()]
    if not subjects or any(subject < 1 or subject > 9 for subject in subjects):
        raise argparse.ArgumentTypeError("subjects must be 1-9 or a comma list within 1..9")
    return subjects


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--subjects", default="1-9")
    parser.add_argument(
        "--decoders",
        nargs="+",
        choices=("primary", "fbcsp"),
        default=("primary", "fbcsp"),
    )
    parser.add_argument("--data-path", default=str(Path.home() / "mne_data"))
    parser.add_argument(
        "--output", default="results/bci_real_application_v4.json"
    )
    parser.add_argument("--n-bootstrap", type=int, default=10_000)
    parser.add_argument("--n-permutations", type=int, default=5_000)
    parser.add_argument("--mne-log-level", default="ERROR")
    args = parser.parse_args()

    mne.set_log_level(args.mne_log_level)
    os.environ["MNE_DATA"] = str(Path(args.data_path).expanduser().resolve())
    output_path = Path(args.output).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    subjects = parse_subjects(args.subjects)
    decoders = tuple(args.decoders)
    cfg = BCIConfig(
        n_bootstrap=args.n_bootstrap,
        n_permutations=args.n_permutations,
    )
    dataset = dataset_instance()

    results = {
        "status": "running",
        "dataset": {
            "name": "BNCI2014_001 / BCI Competition IV Dataset 2a",
            "subjects": subjects,
            "class_order": list(CLASSES),
            "scope": "subject-specific session-T training and session-E evaluation",
        },
        "config": asdict(cfg),
        "software_versions": software_versions(),
        "published_benchmark_context": {
            "Ang_2012_OVR_CSP_mean_evaluation_kappa": 0.503,
            "Ang_2012_OVR_FBCSP_mean_evaluation_kappa": 0.569,
            "comparability_note": (
                "Ang et al. used a time-resolved competition evaluation; these "
                "values are context, not exact fixed-window acceptance targets."
            ),
        },
        "subjects": {},
    }

    try:
        for subject in subjects:
            started = time.time()
            print(f"Processing S{subject}: {', '.join(decoders)}", flush=True)
            results["subjects"][f"S{subject}"] = run_subject(
                dataset, subject, decoders, cfg, output_path.parent
            )
            results["subjects"][f"S{subject}"]["runtime_sec"] = float(
                time.time() - started
            )
            with output_path.open("w", encoding="utf-8") as handle:
                json.dump(results, handle, indent=2)

        for decoder in decoders:
            raw_p = [
                results["subjects"][f"S{subject}"]["decoders"][decoder][
                    "mi_perm_p_raw"
                ]
                for subject in subjects
            ]
            adjusted = holm_adjust(raw_p)
            for subject, p_adjusted in zip(subjects, adjusted):
                results["subjects"][f"S{subject}"]["decoders"][decoder][
                    "mi_perm_p_holm"
                ] = float(p_adjusted)

        results["status"] = "complete"
        results["completed_subjects"] = len(subjects)
        with output_path.open("w", encoding="utf-8") as handle:
            json.dump(results, handle, indent=2)
        print(f"Wrote {output_path}")
    except Exception as error:
        results["status"] = "failed"
        results["error"] = repr(error)
        with output_path.open("w", encoding="utf-8") as handle:
            json.dump(results, handle, indent=2)
        raise


if __name__ == "__main__":
    main()
